Contact {#contact}
========

GLIP is brought to you by a team of researchers of the
[Institute for Integrated Systems (LIS)](http://www.lis.ei.tum.de) at
[TUM](http://www.tum.de).

If you have any questions or want to contribute, please get in contact with us
(also see the [development documentation](@ref development)!) Or alternatively,
just send us Github pull requests!

 - [Philipp Wagner](http://www.lis.ei.tum.de/en/persons/scientific-staff/wagner/)
 - [Stefan Wallentowitz](http://www.lis.ei.tum.de/en/persons/scientific-staff/wallentowitz/)

IRC
---
We usually hang out on the `openrisc` channel on Freenode, look for imphil or wallento.
