Get GLIP {#download}
========


Sources
-------
GLIP is developed using git, you can get the sources from
[Github](https://github.com/TUM-LIS/glip):

    $> git clone https://github.com/TUM-LIS/glip.git

Refer to the INSTALL file inside the source tree for installation instructions.

Binaries
--------
We currently don't offer binaries, but building GLIP should be hassle-free. If
you experience any build problems, please contact us.
