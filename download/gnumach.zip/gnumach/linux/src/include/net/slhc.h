#ifndef __NET_SLHC_H
#define __NET_SLHC_H

extern void slhc_install(void);

#endif
