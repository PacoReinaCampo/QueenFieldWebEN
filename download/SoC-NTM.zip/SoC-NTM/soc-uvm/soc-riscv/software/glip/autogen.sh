#!/bin/sh

autoreconf --install --symlink
