# gzll Kernel

This is the gzll kernel, for more info we refer you to the website
http://www.gzll.org