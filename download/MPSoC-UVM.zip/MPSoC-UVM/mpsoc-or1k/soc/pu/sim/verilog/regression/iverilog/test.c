#include <gelf.h>
void main(void) {}
