#include <stdio.h>

int main(void)
{
    printf("Hello world, from an OpenRISC system!\n");
    return 0;
}
