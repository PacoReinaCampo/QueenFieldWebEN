#ifndef __NODE_MIGRATE_H__
#define __NODE_MIGRATE_H__

int gzll_node_migrate(uint32_t appid, uint32_t taskid, uint32_t dest_rank);

#endif //__NODE_MIGRATE_H__
