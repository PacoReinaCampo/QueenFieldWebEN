# Seven Segment Display decoder

Decodes a 4 bit binary value to a seven segment encoding with this
layout:

    +-0-+
    5   1
    +-6-+
    4   2
    +-3-+
