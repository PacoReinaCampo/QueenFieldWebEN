/* Separate to keep compilation of Space.c simpler */
extern void p8022_proto_init(struct net_proto *);
