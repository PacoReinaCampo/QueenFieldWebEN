#define STORE_DEFINE_EI
#include "store.h"
