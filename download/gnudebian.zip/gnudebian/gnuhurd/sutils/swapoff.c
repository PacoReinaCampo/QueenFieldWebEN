#define SWAPOFF
#include "swapon.c"
