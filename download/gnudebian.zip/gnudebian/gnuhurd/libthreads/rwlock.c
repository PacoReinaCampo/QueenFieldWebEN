#define RWLOCK_DEFINE_EI
#include "rwlock.h"
