/* This file just gives a value that can be tested easily with #if as a
   gross check of the Hurd interface version.  It has the format YYYYMMDD
   and will only ever be increased.  This will be bumped whenever either
   the RPC interfaces or the library APIs change.  */

#define HURD_INTERFACE_VERSION	20020609
