
#define MACH_INLINE 
#include "seg.h"
#include "tss.h"

