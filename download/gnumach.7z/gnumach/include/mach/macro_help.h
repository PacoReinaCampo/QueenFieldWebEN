/* 
 * Mach Operating System
 * Copyright (c) 1988 Carnegie-Mellon University
 * All rights reserved.  The CMU software License Agreement specifies
 * the terms and conditions for use and redistribution.
 */

#ifndef	_MACRO_HELP_H_
#define	_MACRO_HELP_H_	1

#define		MACRO_BEGIN	do {
#define		MACRO_END	} while (0)

#define		MACRO_RETURN	if (1) return

#endif	/* _MACRO_HELP_H_ */


